from django.urls import path
from .views import SendOTPView, VerifyOTPView
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView


app_name = "accounts"


urlpatterns = [
    path('send-otp/', SendOTPView.as_view(), name='send-otp'),
    path('verify-otp/', VerifyOTPView.as_view(), name='verify-otp')
]