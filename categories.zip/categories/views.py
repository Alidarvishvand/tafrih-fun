from rest_framework import viewsets
from .models import Province, Category, SubCategory, SubCategoryMedia
from .serializers import ProvinceSerializer, CategorySerializer, SubCategorySerializer, SubCategoryMediaSerializer


class ProvinceViewSet(viewsets.ModelViewSet):
    queryset = Province.objects.all()
    serializer_class = ProvinceSerializer


class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer


class SubCategoryViewSet(viewsets.ModelViewSet):
    queryset = SubCategory.objects.all()
    serializer_class = SubCategorySerializer


class SubCategoryMediaViewSet(viewsets.ModelViewSet):
    serializer_class = SubCategoryMediaSerializer

    def get_queryset(self):
        queryset = SubCategoryMedia.objects.all()
        province_id = self.request.query_params.get('province')
        if province_id:
            queryset = queryset.filter(subcategory__province_id=province_id)
        return queryset

