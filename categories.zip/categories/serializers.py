from rest_framework import serializers
from .models import Province, Category, SubCategory, SubCategoryMedia

class ProvinceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Province
        fields = ['id', 'name']


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name']


class SubCategorySerializer(serializers.ModelSerializer):
    category = CategorySerializer(read_only=True)
    category_id = serializers.PrimaryKeyRelatedField(queryset=Category.objects.all(), source='category', write_only=True)

    province = ProvinceSerializer(read_only=True)
    province_id = serializers.PrimaryKeyRelatedField(queryset=Province.objects.all(), source='province', write_only=True)

    class Meta:
        model = SubCategory
        fields = ['id', 'name', 'category', 'category_id', 'province', 'province_id']


class SubCategoryMediaSerializer(serializers.ModelSerializer):
    class Meta:
        model = SubCategoryMedia
        fields = ['id', 'subcategory', 'media_type', 'file'] 