from django.contrib import admin
from .models import Province, Category, SubCategory, SubCategoryMedia

# 👇 نمایش مدیاهای مربوط به هر SubCategory (نه Province)
class SubCategoryMediaInline(admin.TabularInline):
    model = SubCategoryMedia
    extra = 0
    fields = ['media_type', 'file']


@admin.register(Province)
class ProvinceAdmin(admin.ModelAdmin):
    list_display = ['name']
    search_fields = ['name']


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name']
    search_fields = ['name']


@admin.register(SubCategory)
class SubCategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'category']  # ✅ حذف 'province'
    list_filter = ['category']
    search_fields = ['name']
    inlines = [SubCategoryMediaInline]


@admin.register(SubCategoryMedia)
class SubCategoryMediaAdmin(admin.ModelAdmin):
    list_display = ['subcategory', 'media_type', 'file']
    list_filter = ['media_type', 'subcategory']
    search_fields = ['subcategory__name']
