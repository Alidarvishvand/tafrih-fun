from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    ProvinceViewSet, CategoryViewSet, SubCategoryViewSet, SubCategoryMediaViewSet
)

router = DefaultRouter()
router.register(r'provinces', ProvinceViewSet, basename='province')
router.register(r'categories', CategoryViewSet, basename='category')
router.register(r'subcategories', SubCategoryViewSet, basename='subcategory')
router.register(r'subcategory-media', SubCategoryMediaViewSet, basename='subcategory-media')

urlpatterns = [
    path('', include(router.urls)),
]
